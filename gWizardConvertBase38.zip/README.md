# gWizardConvertBase38

Swift package for symbolic Base^38, Base62, and Base64 character sets. Used in universal apps and encoded QR systems.

## Includes
- CharsetBase38
- CharsetBase62
- CharsetBase64

Built for the gWizard project.
